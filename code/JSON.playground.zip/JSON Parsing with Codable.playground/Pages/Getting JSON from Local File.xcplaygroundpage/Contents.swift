/*:
 [< Previous](@previous)           [Home](Introduction)           [Next >](@next)

 ## Getting JSON from Local File
You may wish to seed your structs or classes from JSON files that you have stored in the Application Bundle.  Or, you may have stored some JSN in the applications Documents folder and want to restore from that JSON.  This section will show you how to retrive and decode JSON from a file.
*/
import UIKit
/*:
 ### Build the Decodable Model based on the Prettyfied FlatColors.json
 */

/*:
 [< Previous](@previous)           [Home](Introduction)           [Next >](@next)
 */
